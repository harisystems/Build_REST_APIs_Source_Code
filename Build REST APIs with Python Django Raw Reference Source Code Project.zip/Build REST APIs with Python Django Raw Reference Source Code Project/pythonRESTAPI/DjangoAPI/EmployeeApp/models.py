from django.db import models

# Create your models here.
class Deparments(models.Model):
    DepartmentId = models.AutoField(primary_key=True)
    DepartmentName = models.CharField(max_length=300)

class Employees(models.Model):
    EmployeeId = models.AutoField(primary_key=True)
    EmployeeName = models.CharField(max_length=500)
    Department = models.CharField(max_length=50)
    DateOfJoining = models.DateTimeField()
    PhotoFileName = models.CharField(max_length=500)


